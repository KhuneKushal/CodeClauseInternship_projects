package com.raven.event;

public interface EventLogin {

    public void login();

    public void register();

    public void goRegister();

    public void goLogin();
}
